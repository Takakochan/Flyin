#!/usr/bin/env python3
"""
Test runner for the drone-pathfinding project.

Usage:
    python3 run_all.py "./main.py"
    python3 run_all.py "python3 main.py"

It runs every map in tests/ and reports:
  - valid maps  : exit code, line count (turn proxy), elapsed time
  - error maps  : whether the program rejected it (non-zero exit OR stderr text)

NOTE on "turns": this counts non-empty stdout lines as a proxy for turns,
assuming one output line per turn (lem-in style). If your output format
differs, treat the number as a rough signal, not ground truth.
"""
import sys, os, subprocess, shlex, time, glob

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "tests")

# Folders whose maps are SUPPOSED to be rejected by the parser.
ERROR_DIRS = {"01_parser_errors"}
# Individual maps that should be rejected even though they live elsewhere.
ERROR_MAPS = {"invalid_connection.txt"}

# Rough expected turn counts for quick sanity (None = no fixed expectation).
EXPECTED = {
    "linear.txt": 3,
    "zone_capacity.txt": 3,
    "bottleneck.txt": 5,
    "single_drone_trivial.txt": 1,
    "extreme_capacity.txt": 2,
    "link_capacity_low.txt": 3,
    "link_capacity_high.txt": 2,
    "multi_path.txt": 3,
}

def run(cmd, mapfile):
    full = shlex.split(cmd) + [mapfile]
    t0 = time.perf_counter()
    try:
        p = subprocess.run(full, capture_output=True, text=True, timeout=30)
    except subprocess.TimeoutExpired:
        return None, "", "TIMEOUT", time.perf_counter() - t0
    dt = time.perf_counter() - t0
    return p.returncode, p.stdout, p.stderr, dt

def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    cmd = sys.argv[1]

    maps = sorted(glob.glob(os.path.join(ROOT, "*", "*.txt")))
    if not maps:
        print(f"No maps found under {ROOT}")
        sys.exit(1)

    ok = warn = 0
    for m in maps:
        rel = os.path.relpath(m, ROOT)
        folder = rel.split(os.sep)[0]
        name = os.path.basename(m)
        expect_error = folder in ERROR_DIRS or name in ERROR_MAPS

        rc, out, err, dt = run(cmd, m)
        lines = [l for l in out.splitlines() if l.strip()]
        turns = len(lines)

        if expect_error:
            rejected = (rc not in (0, None)) or bool(err.strip())
            tag = "OK  " if rejected else "FAIL"
            if rejected: ok += 1
            else: warn += 1
            print(f"[{tag}] {rel:<42} expected-error  rc={rc}  "
                  f"{'rejected' if rejected else 'ACCEPTED (bad!)'}")
        else:
            crashed = rc not in (0, None) or err.strip() == "TIMEOUT"
            note = f"turns={turns:<3} {dt*1000:6.1f}ms"
            exp = EXPECTED.get(name)
            if exp is not None:
                note += f"  (expected ~{exp})"
                if turns != exp:
                    note += "  <- differs"
            if crashed:
                warn += 1
                print(f"[FAIL] {rel:<42} rc={rc}  {err.strip()[:60]}")
            else:
                ok += 1
                print(f"[OK  ] {rel:<42} {note}")

    print(f"\n{ok} ok, {warn} need attention, {len(maps)} total")

if __name__ == "__main__":
    main()
